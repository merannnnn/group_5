/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameonlinestoresystem;

/**
 *
 * @author Dell
 */
import java.util.*;
public class AccountManager {
    ArrayList<Customer> customer=new ArrayList<Customer>();
    ArrayList<Vendor> vendor= new ArrayList<Vendor>();
    ArrayList<customerService> customerService=new ArrayList<customerService>();
    
    public void verifyLogin()
    {
        
    }
}
